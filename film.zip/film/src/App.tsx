import "./App.css";

function App() {
  return (
    <div>
      <header>
        <img src="src/fiim/Без названия (2).png" alt="kinopoisk" />
      </header>
      <div>
        <img src="src/fiim/600x900 (1).webp" alt="film1" />
        <a href="https://www.kinopoisk.ru/film/4771048/">ссылка</a>
        <img src="src/fiim/600x900 (2).webp" alt="film1" />
        <a href="https://www.kinopoisk.ru/series/95323/">ссылка</a>
        <img src="src/fiim/600x900 (3).webp" alt="film1" />
        <a href="https://www.kinopoisk.ru/series/408674/">ссылка</a>
        <img src="src/fiim/600x900.webp" alt="film2" />
        <a href="https://www.kinopoisk.ru/film/1005008/">ссылка</a>
        <img
          src="src/fiim/h6_Fk_Ce75AYaJuWkkmoqTgDnDOORUzI4OMNnjSD-xeXQR6rLwUDOiOAUe636vnTqAujlT6LVky_4W5RwBDCYAe-BYQ0GfnQj-4JQofJKK-qFkmgiBdYGeen2YmjSDcdm8tCIqDPCzE70AC_cD0vhHgO9UP7HBHIun31lB5I3P4KqcRc8QRg05h_lx0fRiSmq8QVtJ1Jw8014QacNIm8W.webp"
          alt="film2"
        />
        <a href="https://www.kinopoisk.ru/series/749374/">ссылка</a>
        <img
          src="src/fiim/h6_Fk_Ce75AYaJuWkkmoqTgDnDOORUzI4OMNnjSD-xeXQR6rLwUDOiOBkW93qzvSrZk21WnKgoy-smkSFMVEplL8kYEnDfjHSOhcgwQdqa_9lV2jSITeWGe1ycvjU_caG8uFZqeJyLK6HkC_ZmxvBbhJMoJ9mgCfu7d1i8XP3bjM54bW_8gl3R4_2VwaBidiYgBZfl-EQMOzZ48U9sQ2k.webp"
          alt="film2"
        />
        <a href="https://www.kinopoisk.ru/film/5249455/">ссылка</a>
      </div>
    </div>
  );
}

export default App;
